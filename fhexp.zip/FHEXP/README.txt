WARNING: THIS MAY CAUSE SYSTEM CRASHES IF NOT HANDLED PROPERLY!!!

COMPATIBILITY: Works only with DOS environments/applications (e.g., DOSBox, FreeDOS)

ILLEGAL NOTE: PLEASE DO NOT USE ANY OF THIS FOR ILLEGAL ACTIVITIES!!! Such behaviour will not be accepted on either side and may lead to you potentially facing legal consequence's.

Steps required to run:

1. Download a DOSBox(Please read their README files though, all of it please)
links(Copy & paste them):

DOSBox
https://www.dosbox.com/download.php?main=1

FreeDOS
https://www.freedos.org/download/

2. Setup them and download their wizards.

3. Once their downloaded launch them.

4. Unzip FHEXP and extract it directly to c: to simplify things.

5. 2ND WARNING: A SINGLE MISTAKE MAY CAUSE A SYSTEM CRASH!!! Write on your DOS:

mount c c:\FHEXP

6. Write

c c:Hello_world

;or you could write for the other file.

c c:a

This was made using:
HxD(A Hex editor)
DOSBox(A DOS)

Thank you for your time.